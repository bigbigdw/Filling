package com.example.filling.Drawer.Complain;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.filling.R;

public class Complain_Result extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.complain_detail);



    }

}
